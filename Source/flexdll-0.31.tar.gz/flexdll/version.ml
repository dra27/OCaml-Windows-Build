let version = "0.31"
let mingw_prefix = "i686-w64-mingw32"
let mingw64_prefix = "x86_64-w64-mingw32"
