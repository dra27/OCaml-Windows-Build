#include "stdio.h"
int x = 10;
void dump_x() { printf("AAA\nx=%i\n", x); }
void torun() { api("plug1.torun();"); }

