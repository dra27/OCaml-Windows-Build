var o = new Object();
o;
o.x=1;
(o.x);
