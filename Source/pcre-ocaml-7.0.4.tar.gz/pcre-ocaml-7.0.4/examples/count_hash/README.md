This program reads in text from stdin, counts all equal words that are
separated by whitespace and prints the result to stdout.
