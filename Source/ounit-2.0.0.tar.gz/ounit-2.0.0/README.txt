(* OASIS_START *)
(* DO NOT EDIT (digest: ac260da3dc5dbc8b63343daec02e41ac) *)
This is the README file for the ounit distribution.

(C) 2002-2008 Maas-Maarten Zeeman

(C) 2010 OCamlCore SARL

Unit testing framework

OUnit is a unit testing framework for OCaml, inspired by the JUnit tool for
Java, and the HUnit tool for Haskell.

More information on [HUnit](http://hunit.sourceforge.net)

See the files INSTALL.txt for building and installation instructions. See the
file LICENSE.txt for copying conditions. 

Home page: http://ounit.forge.ocamlcore.org


(* OASIS_STOP *)
