#! /bin/sh
export OCAMLPATH=../../../src
make
