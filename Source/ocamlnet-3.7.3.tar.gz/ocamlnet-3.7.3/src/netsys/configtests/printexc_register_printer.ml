let () =
  Printexc.register_printer (fun _ -> None)
